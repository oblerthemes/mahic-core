<?php
/*======
*
* Kirki Settings
*
======*/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Kirki' ) ) {
	return;
}

Kirki::add_config(
	'mahic_customizer', array(
		'capability'  => 'edit_theme_options',
		'option_type' => 'theme_mod',
	)
);

/*======
*
* Sections
*
======*/
$sections = array(
	'shop_settings' => array (
		esc_attr__( 'Shop Settings', 'mahic' ),
		esc_attr__( 'You can customize the shop settings.', 'mahic' ),
	),
	
	'blog_settings' => array (
		esc_attr__( 'Blog Settings', 'mahic' ),
		esc_attr__( 'You can customize the blog settings.', 'mahic' ),
	),

	'header_settings' => array (
		esc_attr__( 'Header Settings', 'mahic' ),
		esc_attr__( 'You can customize the header settings.', 'mahic' ),
	),

	'main_color' => array (
		esc_attr__( 'Main Color', 'mahic' ),
		esc_attr__( 'You can customize the main color.', 'mahic' ),
	),

	'elementor_templates' => array (
		esc_attr__( 'Elementor Templates', 'mahic-core' ),
		esc_attr__( 'You can customize the elementor templates.', 'mahic-core' ),
	),
	
	'map_settings' => array (
		esc_attr__( 'Map Settings', 'mahic' ),
		esc_attr__( 'You can customize the map settings.', 'mahic' ),
	),

	'footer_settings' => array (
		esc_attr__( 'Footer Settings', 'mahic' ),
		esc_attr__( 'You can customize the footer settings.', 'mahic' ),
	),

	'newsletter_settings' => array (
		esc_attr__( 'Newsletter Settings', 'mahic-core' ),
		esc_attr__( 'You can customize the Newsletter Popup settings.', 'mahic-core' ),
	),

	'gdpr_settings' => array (
		esc_attr__( 'GDPR Settings', 'mahic-core' ),
		esc_attr__( 'You can customize the GDPR settings.', 'mahic-core' ),
	),

	'maintenance_settings' => array (
		esc_attr__( 'Maintenance Settings', 'mahic-core' ),
		esc_attr__( 'You can customize the Maintenance settings.', 'mahic-core' ),
	),

);

foreach ( $sections as $section_id => $section ) {
	$section_args = array(
		'title' => $section[0],
		'description' => $section[1],
	);

	if ( isset( $section[2] ) ) {
		$section_args['type'] = $section[2];
	}

	if( $section_id == "colors" ) {
		Kirki::add_section( str_replace( '-', '_', $section_id ), $section_args );
	} else {
		Kirki::add_section( 'mahic_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
	}
}


/*======
*
* Fields
*
======*/
function mahic_customizer_add_field ( $args ) {
	Kirki::add_field(
		'mahic_customizer',
		$args
	);
}

	/*====== Header ==================================================================================*/
		/*====== Header Panels ======*/
		Kirki::add_panel (
			'mahic_header_panel',
			array(
				'title' => esc_html__( 'Header Settings', 'mahic' ),
				'description' => esc_html__( 'You can customize the header from this panel.', 'mahic' ),
			)
		);

		$sections = array (
			'header_logo' => array(
				esc_attr__( 'Logo', 'mahic' ),
				esc_attr__( 'You can customize the logo which is on header..', 'mahic' )
			),
		
			'header_general' => array(
				esc_attr__( 'Header General', 'mahic' ),
				esc_attr__( 'You can customize the header.', 'mahic' )
			),
			
			'header_product_tab' => array(
				esc_attr__( 'Header Products Tab', 'mahic' ),
				esc_attr__( 'You can customize the header products tab.', 'mahic' )
			),

			'header_preloader' => array(
				esc_attr__( 'Preloader', 'mahic' ),
				esc_attr__( 'You can customize the loader.', 'mahic' )
			),
			
			'header1_style' => array(
				esc_attr__( 'Header 1 Style', 'mahic' ),
				esc_attr__( 'You can customize the style.', 'mahic' )
			),
			
			'header2_style' => array(
				esc_attr__( 'Header 2 Style', 'mahic' ),
				esc_attr__( 'You can customize the style.', 'mahic' )
			),
			
			'header3_style' => array(
				esc_attr__( 'Header 3 Style', 'mahic' ),
				esc_attr__( 'You can customize the style.', 'mahic' )
			),
			
			'header4_style' => array(
				esc_attr__( 'Header 4 Style', 'mahic' ),
				esc_attr__( 'You can customize the style.', 'mahic' )
			),
			
			'header_mobile_sidebar_menu_style' => array(
				esc_attr__( 'Mobile Sidebar Menu Style', 'mahic-core' ),
				esc_attr__( 'You can customize the style.', 'mahic-core' )
			),

		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'mahic_header_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'mahic_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}
		
		/*====== Logo ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'mahic_logo',
				'label' => esc_attr__( 'Logo', 'mahic' ),
				'description' => esc_attr__( 'You can upload a logo.', 'mahic' ),
				'section' => 'mahic_header_logo_section',
				'choices' => array(
					'save_as' => 'id',
				),
			)
		);
		
		/*====== Logo White ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'mahic_logo_white',
				'label' => esc_attr__( 'Logo White', 'mahic' ),
				'description' => esc_attr__( 'You can upload a logo.', 'mahic' ),
				'section' => 'mahic_header_logo_section',
				'choices' => array(
					'save_as' => 'id',
				),
			)
		);
		
		/*====== Logo Text ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_logo_text',
				'label' => esc_attr__( 'Set Logo Text', 'mahic' ),
				'description' => esc_attr__( 'You can set logo as text.', 'mahic' ),
				'section' => 'mahic_header_logo_section',
				'default' => 'mahic',
			)
		);
		
		/*====== Logo Size ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'mahic_logo_size',
				'label'       => esc_html__( 'Logo Size', 'mahic-core' ),
				'description' => esc_attr__( 'You can set size of the logo.', 'mahic-core' ),
				'section'     => 'mahic_header_logo_section',
				'default'     => 171,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 20,
					'max'  => 400,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.site-brand a img',
					'property'    => 'width',
					'units' => 'px',
				], ],
			)
		);
		
		/*====== Mobil Logo Size ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'mahic_mobil_logo_size',
				'label'       => esc_html__( 'Mobile Logo Size', 'mahic-core' ),
				'description' => esc_attr__( 'You can set size of the mobil logo.', 'mahic-core' ),
				'section'     => 'mahic_header_logo_section',
				'default'     => 135,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 20,
					'max'  => 300,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.site-header .header-mobile .site-brand img',
					'property'    => 'width',
					'units' => 'px',
				], ],
			)
		);
		
		/*====== Sidebar Logo Size ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'mahic_sidebar_logo_size',
				'label'       => esc_html__( 'Sidebar Logo Size', 'mahic-core' ),
				'description' => esc_attr__( 'You can set size of the sidebar logo.', 'mahic-core' ),
				'section'     => 'mahic_header_logo_section',
				'default'     => 115,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 20,
					'max'  => 300,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.site-offcanvas-header .site-brand img',
					'property'    => 'width',
					'units' => 'px',
				], ],
			)
		);
		
		mahic_customizer_add_field(
			array (
			'type'        => 'select',
			'settings'    => 'mahic_header_type',
			'label'       => esc_html__( 'Header Type', 'mahic-core' ),
			'section'     => 'mahic_header_general_section',
			'default'     => 'type-1',
			'priority'    => 10,
			'choices'     => array(
				'type1' => esc_attr__( 'Type 1', 'mahic-core' ),
				'type2' => esc_attr__( 'Type 2', 'mahic-core' ),
				'type3' => esc_attr__( 'Type 3', 'mahic-core' ),
				'type4' => esc_attr__( 'Type 4', 'mahic-core' ),
			),
			) 
		);

		/*====== Mobile Sticky Header Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_mobile_sticky_header',
				'label' => esc_attr__( 'Mobile Sticky Header', 'mahic-core' ),
				'description' => esc_attr__( 'You can choose status of the header on the mobile.', 'mahic-core' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Header Search Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_search',
				'label' => esc_attr__( 'Header Search', 'mahic' ),
				'description' => esc_attr__( 'You can choose status of the search on the header.', 'mahic' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Ajax Search Form ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_ajax_search_form',
				'label' => esc_attr__( 'Ajax Search Form', 'mahic-core' ),
				'description' => esc_attr__( 'Enable ajax search form for the header search.', 'mahic-core' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_search',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Cart Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_cart',
				'label' => esc_attr__( 'Header Cart', 'mahic' ),
				'description' => esc_attr__( 'You can choose status of the mini cart on the header.', 'mahic' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Header Mini Cart Type ======*/
		mahic_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'mahic_header_mini_cart_type',
			'label'       => esc_html__( 'Mini Cart Type', 'mahic-core' ),
			'section'     => 'mahic_header_general_section',
			'default'     => 'default',
			'priority'    => 10,
			'choices'     => array(
				'slider' => esc_attr__( 'Slider', 'mahic-core' ),
				'sidecart' => esc_attr__( 'Side Cart', 'mahic-core' ),
				'default' => esc_attr__( 'Default', 'mahic-core' ),
			),
			'required' => array(
				array(
				  'setting'  => 'mahic_header_cart',
				  'operator' => '==',
				  'value'    => '1',
				),
			),
			) 
		);
		
		/*====== Header Mini Cart Notice ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_header_mini_cart_notice',
				'label' => esc_attr__( 'Mini Cart Notice', 'mahic-core' ),
				'description' => esc_attr__( 'You can add a text for the mini cart.', 'mahic-core' ),
				'section' => 'mahic_header_general_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_cart',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		
		
		/*====== Header Account Icon ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_account',
				'label' => esc_attr__( 'Account Icon / Login', 'mahic' ),
				'description' => esc_attr__( 'Disable or Enable User Login/Signup on the header.', 'mahic' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Header Wishlist  ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_wishlist',
				'label' => esc_attr__( 'Wishlist', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable wishlist on the header.', 'mahic-core' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Header Sidebar ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_sidebar',
				'label' => esc_attr__( 'Sidebar Menu', 'mahic' ),
				'description' => esc_attr__( 'Disable or Enable Sidebar Menu', 'mahic' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
			)
		);

		/*====== Header Sidebar Collapse ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_sidebar_collapse',
				'label' => esc_attr__( 'Disable Collapse on Frontpage', 'mahic' ),
				'description' => esc_attr__( 'Disable or Enable Sidebar Collapse on Home Page.', 'mahic' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_sidebar',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Top Header Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_top_header',
				'label' => esc_attr__( 'Top Header', 'mahic' ),
				'description' => esc_attr__( 'Disable or Enable the top header.', 'mahic' ),
				'section' => 'mahic_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Header Products Tab Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_products_tab',
				'label' => esc_attr__( 'Products Tab', 'mahic' ),
				'description' => esc_attr__( 'Disable or Enable Products Tab', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => '0',
			)
		);
		
		/*====== Header Products Tab Button Title ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_header_products_button_title',
				'label' => esc_attr__( 'Button Title', 'mahic' ),
				'description' => esc_attr__( 'You can add a text for the button.', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => 'Super Discount',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_products_tab',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Products Tab Button Subtitle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_header_products_button_subtitle',
				'label' => esc_attr__( 'Button Subtitle', 'mahic' ),
				'description' => esc_attr__( 'You can add a subtitle for the button.', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => 'Only this weekend',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_products_tab',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Products Tab Title ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_header_products_tab_title',
				'label' => esc_attr__( 'Tab Title', 'mahic' ),
				'description' => esc_attr__( 'You can add a title for the tab.', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => 'Items on sale this week',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_products_tab',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Products Tab Subtitle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_header_products_tab_subtitle',
				'label' => esc_attr__( 'Tab Subtitle', 'mahic' ),
				'description' => esc_attr__( 'You can add a subtitle for the tab.', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => 'Top picks this week. Up to 50% off the best selling products.',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_products_tab',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Products Tab On Sale ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_products_tab_on_sale',
				'label' => esc_attr__( 'On Sale Products?', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_products_tab',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Products Tab Featured ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_products_tab_featured',
				'label' => esc_attr__( 'Featured Products?', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_products_tab',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Products Tab Best Selling ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_header_products_tab_best_selling',
				'label' => esc_attr__( 'Best Selling Products?', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_products_tab',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Products Tab Post count ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_header_products_tab_post_count',
				'label' => esc_attr__( 'Posts Count', 'mahic' ),
				'section' => 'mahic_header_product_tab_section',
				'default' => '6',
				'required' => array(
					array(
					  'setting'  => 'mahic_header_products_tab',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Products Tab Button Title Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_products_tab_bg_color',
				'label' => esc_attr__( 'Products Tab Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header_product_tab_section',
			)
		);
		
		/*====== Header Products Tab Title Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_tab_title_color',
				'label' => esc_attr__( 'Tab Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header_product_tab_section',
			)
		);
		
		/*====== Header Products Tab Title Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_tab_title_hvrcolor',
				'label' => esc_attr__( 'Tab Title Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header_product_tab_section',
			)
		);
		
		/*====== Header Products Tab Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_tab_subtitle_color',
				'label' => esc_attr__( 'Tab Subtitle Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header_product_tab_section',
			)
		);
		
		/*====== Header Products Tab Subtitle Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_tab_subtitle_hvrcolor',
				'label' => esc_attr__( 'Tab Subtitle Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header_product_tab_section',
			)
		);

		/*====== PreLoader Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_preloader',
				'label' => esc_attr__( 'Enable Loader', 'mahic' ),
				'description' => esc_attr__( 'Disable or Enable the loader.', 'mahic' ),
				'section' => 'mahic_header_preloader_section',
				'default' => '0',
			)
		);
		
		/*====== Top Header1 Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header1_top_bg_color',
				'label' => esc_attr__( 'Top Header Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Top Header1 Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header1_top_color',
				'label' => esc_attr__( 'Top Header Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Top Header1 Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header1_top_hvrcolor',
				'label' => esc_attr__( 'Top Header Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for hover color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header1_bg_color',
				'label' => esc_attr__( 'Header Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Search Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#041e42',
				'settings' => 'mahic_header1_search_bg_color',
				'label' => esc_attr__( 'Header Search Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Search Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header1_search_font_color',
				'label' => esc_attr__( 'Header Search Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header1_font_color',
				'label' => esc_attr__( 'Header Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header1_font_hvrcolor',
				'label' => esc_attr__( 'Header Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font hover color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Submenu Title Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header1_sub_title_font_color',
				'label' => esc_attr__( 'Header Submenu Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Icon Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header1_icon_color',
				'label' => esc_attr__( 'Header Icon Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a icon color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Counter Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header1_counter_bg_color',
				'label' => esc_attr__( 'Header Counter Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a counter background.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Sidebar Menu Main Title Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#f7f8f9',
				'settings' => 'mahic_header1_sidebar_title_bg',
				'label' => esc_attr__( 'Sidebar Title Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*======Header1  Sidebar Menu Main Title Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header1_sidebar_title_font_color',
				'label' => esc_attr__( 'Sidebar Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Sidebar Menu Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header1_sidebar_bg',
				'label' => esc_attr__( 'Sidebar Menu Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Sidebar Menu Border Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e5e8ec',
				'settings' => 'mahic_header1_sidebar_brdrcolor',
				'label' => esc_attr__( 'Sidebar Menu Border Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for border color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*======  Header1 Sidebar Menu Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header1_sidebar_font_color',
				'label' => esc_attr__( 'Sidebar Menu Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Header1 Sidebar Menu Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header1_sidebar_font_hvrcolor',
				'label' => esc_attr__( 'Sidebar Menu Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*======  Header1 Sidebar Menu Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header1_sidebar_subtitle_font_color',
				'label' => esc_attr__( 'Sidebar Menu Subtitle Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a  font color.', 'mahic-core' ),
				'section' => 'mahic_header1_style_section',
			)
		);
		
		/*====== Top Header Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header1_top_header_size',
				'label'       => esc_attr__( 'Top Header Typography', 'mahic-core' ),
				'section'     => 'mahic_header1_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '12px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => ' .header-type1 .header-top ',
					],
				],
			)
		);
		
		/*====== Header Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header1_main_size',
				'label'       => esc_attr__( 'Header Typography', 'mahic-core' ),
				'section'     => 'mahic_header1_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '15px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => ' .header-type1 .site-menu.primary a ',
					],
				],
			)
		);
		
		/*====== Sidebar Menu Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header1_sidebar_size',
				'label'       => esc_attr__( 'Sidebar Menu Typography', 'mahic-core' ),
				'section'     => 'mahic_header1_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '13px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.header-type1 .site-departments .departments-menu a',
					],
				],
			)
		);
		
		/*====== Top Header2 Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header2_top_bg_color',
				'label' => esc_attr__( 'Top Header Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Top Header2 Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_top_color',
				'label' => esc_attr__( 'Top Header Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Top Header2 Font Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header2_top_hvrcolor',
				'label' => esc_attr__( 'Top Header Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for hover color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header2_bg_color',
				'label' => esc_attr__( 'Header Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Search Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#041e42',
				'settings' => 'mahic_header2_search_bg_color',
				'label' => esc_attr__( 'Header Search Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Search Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header2_search_font_color',
				'label' => esc_attr__( 'Header Search Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_font_color',
				'label' => esc_attr__( 'Header Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_font_hvrcolor',
				'label' => esc_attr__( 'Header Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font hover color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Submenu Title Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_sub_title_font_color',
				'label' => esc_attr__( 'Header Submenu Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Icon Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_icon_color',
				'label' => esc_attr__( 'Header Icon Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a icon color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Counter Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header2_counter_bg_color',
				'label' => esc_attr__( 'Header Counter Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a counter background.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Search Column  Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffc21f',
				'settings' => 'mahic_header2_search_column_bg_color',
				'label' => esc_attr__( 'Header Search Column Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Search Column  Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_search_column_font_color',
				'label' => esc_attr__( 'Header Search Column Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Search Column Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_search_column_font_hvrcolor',
				'label' => esc_attr__( 'Header Search Column Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font hover color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Sidebar Menu Main Title Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffc21f',
				'settings' => 'mahic_header2_sidebar_title_bg',
				'label' => esc_attr__( 'Sidebar Title Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*======Header2 Sidebar Menu Main Title Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_sidebar_title_font_color',
				'label' => esc_attr__( 'Sidebar Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Sidebar Menu Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header2_sidebar_bg',
				'label' => esc_attr__( 'Sidebar Menu Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Sidebar Menu Border Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e5e8ec',
				'settings' => 'mahic_header2_sidebar_brdrcolor',
				'label' => esc_attr__( 'Sidebar Menu Border Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for border color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*======  Header2 Sidebar Menu Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_sidebar_font_color',
				'label' => esc_attr__( 'Sidebar Menu Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*====== Header2 Sidebar Menu Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header2_sidebar_font_hvrcolor',
				'label' => esc_attr__( 'Sidebar Menu Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*======  Header2 Sidebar Menu Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header2_sidebar_subtitle_font_color',
				'label' => esc_attr__( 'Sidebar Menu Subtitle Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a  font color.', 'mahic-core' ),
				'section' => 'mahic_header2_style_section',
			)
		);
		
		/*======Header2 Top Header Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header2_top_header_size',
				'label'       => esc_attr__( 'Top Header Typography', 'mahic-core' ),
				'section'     => 'mahic_header2_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '12px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => ' .klb-type2 .header-top ',
					],
				],
			)
		);
		
		/*====== Header2 Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header2_main_size',
				'label'       => esc_attr__( 'Header Typography', 'mahic-core' ),
				'section'     => 'mahic_header2_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '15px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => ' .klb-type2 .site-menu.primary a ',
					],
				],
			)
		);
		
		/*====== Header2 Sidebar Menu Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header2_sidebar_size',
				'label'       => esc_attr__( 'Sidebar Menu Typography', 'mahic-core' ),
				'section'     => 'mahic_header2_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '13px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.klb-type2 .site-departments .departments-menu a',
					],
				],
			)
		);
		
		/*====== Top Header3 Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#031424',
				'settings' => 'mahic_header3_top_bg_color',
				'label' => esc_attr__( 'Top Header Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Top Header3 Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header3_top_color',
				'label' => esc_attr__( 'Top Header Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Top Header3 Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header3_top_hvrcolor',
				'label' => esc_attr__( 'Top Header Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for hover color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Top Header3 Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header3_subtitle_top_color',
				'label' => esc_attr__( 'Top Header Subtitle Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Top Header3 Subtitle Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header3_subtitle_top_hvrcolor',
				'label' => esc_attr__( 'Top Header Subtitle Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#031424',
				'settings' => 'mahic_header3_bg_color',
				'label' => esc_attr__( 'Header Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Mobile Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header3_mobile_bg_color',
				'label' => esc_attr__( 'Header Mobile Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Search Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header3_search_bg_color',
				'label' => esc_attr__( 'Header Search Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Search Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header3_search_font_color',
				'label' => esc_attr__( 'Header Search Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header3_font_color',
				'label' => esc_attr__( 'Header Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Font Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header3_font_hvrcolor',
				'label' => esc_attr__( 'Header Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font hover color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Submenu Title Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header3_sub_title_font_color',
				'label' => esc_attr__( 'Header Submenu Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Submenu Subtitle Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header3_sub_subtitle_font_color',
				'label' => esc_attr__( 'Header Submenu Subtitle Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Submenu Subtitle Font Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header3_sub_subtitle_font_hvrcolor',
				'label' => esc_attr__( 'Header Submenu Subtitle Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font hover color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Icon Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header3_icon_color',
				'label' => esc_attr__( 'Header Icon Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a icon color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Counter Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header3_counter_bg_color',
				'label' => esc_attr__( 'Header Counter Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a counter background.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Sidebar Menu Main Title Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header3_sidebar_title_bg',
				'label' => esc_attr__( 'Sidebar Title Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*======Header3  Sidebar Menu Main Title Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header3_sidebar_title_font_color',
				'label' => esc_attr__( 'Sidebar Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Sidebar Menu Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header3_sidebar_bg',
				'label' => esc_attr__( 'Sidebar Menu Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Sidebar Menu Border Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e5e8ec',
				'settings' => 'mahic_header3_sidebar_brdrcolor',
				'label' => esc_attr__( 'Sidebar Menu Border Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for border color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*======  Header3 Sidebar Menu Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header3_sidebar_font_color',
				'label' => esc_attr__( 'Sidebar Menu Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Sidebar Menu Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header3_sidebar_font_hvrcolor',
				'label' => esc_attr__( 'Sidebar Menu Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*======  Header3 Sidebar Menu Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header3_sidebar_subtitle_font_color',
				'label' => esc_attr__( 'Sidebar Menu Subtitle Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a  font color.', 'mahic-core' ),
				'section' => 'mahic_header3_style_section',
			)
		);
		
		/*====== Header3 Top Header Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header3_top_header_size',
				'label'       => esc_attr__( 'Top Header Typography', 'mahic-core' ),
				'section'     => 'mahic_header3_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '12px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => ' .header-type3 .header-top ',
					],
				],
			)
		);
		
		/*====== Header3 Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header3_main_size',
				'label'       => esc_attr__( 'Header Typography', 'mahic-core' ),
				'section'     => 'mahic_header3_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '15px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => ' .header-type3 .site-menu.primary a ',
					],
				],
			)
		);
		
		/*====== Header3 Sidebar Menu Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header3_sidebar_size',
				'label'       => esc_attr__( 'Sidebar Menu Typography', 'mahic-core' ),
				'section'     => 'mahic_header3_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '13px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.header-type3 .site-departments .departments-menu a',
					],
				],
			)
		);
		
		/*====== Top Header4 Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#031424',
				'settings' => 'mahic_header4_top_bg_color',
				'label' => esc_attr__( 'Top Header Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Top Header4 Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header4_top_color',
				'label' => esc_attr__( 'Top Header Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Top Header4 Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header4_top_hvrcolor',
				'label' => esc_attr__( 'Top Header Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for hover color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Top Header4 Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_subtitle_top_color',
				'label' => esc_attr__( 'Top Header Subtitle Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Top Header4 Subtitle Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header4_subtitle_top_hvrcolor',
				'label' => esc_attr__( 'Top Header Subtitle Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#031424',
				'settings' => 'mahic_header4_bg_color',
				'label' => esc_attr__( 'Header Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Mobile Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header4_mobile_bg_color',
				'label' => esc_attr__( 'Header Mobile Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Search Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#041e42',
				'settings' => 'mahic_header4_search_bg_color',
				'label' => esc_attr__( 'Header Search Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Search Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header4_search_font_color',
				'label' => esc_attr__( 'Header Search Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header4_font_color',
				'label' => esc_attr__( 'Header Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Font Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header4_font_hvrcolor',
				'label' => esc_attr__( 'Header Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font hover color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Submenu Title Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_sub_title_font_color',
				'label' => esc_attr__( 'Header Submenu Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Submenu Subtitle Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_sub_subtitle_font_color',
				'label' => esc_attr__( 'Header Submenu Subtitle Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Submenu Subtitle Font Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_sub_subtitle_font_hvrcolor',
				'label' => esc_attr__( 'Header Submenu Subtitle Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font hover color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Icon Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header4_icon_color',
				'label' => esc_attr__( 'Header Icon Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a icon color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Counter Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_header4_counter_bg_color',
				'label' => esc_attr__( 'Header Counter Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a counter background.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Search Column  Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffc21f',
				'settings' => 'mahic_header4_search_column_bg_color',
				'label' => esc_attr__( 'Header Search Column Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Search Column  Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_search_column_font_color',
				'label' => esc_attr__( 'Header Search Column Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Search Column Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_search_column_font_hvrcolor',
				'label' => esc_attr__( 'Header Search Column Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font hover color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Sidebar Menu Main Title Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffc21f',
				'settings' => 'mahic_header4_sidebar_title_bg',
				'label' => esc_attr__( 'Sidebar Title Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*======Header4 Sidebar Menu Main Title Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_sidebar_title_font_color',
				'label' => esc_attr__( 'Sidebar Title Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Sidebar Menu Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_header4_sidebar_bg',
				'label' => esc_attr__( 'Sidebar Menu Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Sidebar Menu Border Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e5e8ec',
				'settings' => 'mahic_header4_sidebar_brdrcolor',
				'label' => esc_attr__( 'Sidebar Menu Border Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for border color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*======  Header4 Sidebar Menu Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_sidebar_font_color',
				'label' => esc_attr__( 'Sidebar Menu Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*====== Header4 Sidebar Menu Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_header4_sidebar_font_hvrcolor',
				'label' => esc_attr__( 'Sidebar Menu Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*======  Header4 Sidebar Menu Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_header4_sidebar_subtitle_font_color',
				'label' => esc_attr__( 'Sidebar Menu Subtitle Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a  font color.', 'mahic-core' ),
				'section' => 'mahic_header4_style_section',
			)
		);
		
		/*======Header4 Top Header Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header4_top_header_size',
				'label'       => esc_attr__( 'Top Header Typography', 'mahic-core' ),
				'section'     => 'mahic_header4_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '12px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => ' .klb-type4 .header-top ',
					],
				],
			)
		);
		
		/*====== Header4 Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header4_main_size',
				'label'       => esc_attr__( 'Header Typography', 'mahic-core' ),
				'section'     => 'mahic_header4_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '15px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => ' .klb-type4 .site-menu.primary a ',
					],
				],
			)
		);
		
		/*====== Header4 Sidebar Menu Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_header4_sidebar_size',
				'label'       => esc_attr__( 'Sidebar Menu Typography', 'mahic-core' ),
				'section'     => 'mahic_header4_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '13px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.klb-type4 .site-departments .departments-menu a',
					],
				],
			)
		);

	/*====== Mobile Sidebar Menu Style ======*/	
	
		/*======  Mobile Sidebar Menu Top Background ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#031624',
				'settings' => 'mahic_mobile_sidebar_menu_top_bg',
				'label' => esc_attr__( 'Mobile Sidebar Menu Top Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a background-color.', 'mahic-core' ),
				'section' => 'mahic_header_mobile_sidebar_menu_style_section',
			)
		);
		
		/*======  Mobile Sidebar Menu Background ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_mobile_sidebar_menu_bg',
				'label' => esc_attr__( 'Mobile Sidebar Menu Background', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a background-color.', 'mahic-core' ),
				'section' => 'mahic_header_mobile_sidebar_menu_style_section',
			)
		);
		
		/*======  Mobile Sidebar Menu Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_mobile_sidebar_menu_color',
				'label' => esc_attr__( 'Mobile Sidebar Menu Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'mahic-core' ),
				'section' => 'mahic_header_mobile_sidebar_menu_style_section',
			)
		);
		
		/*======  Mobile Sidebar Menu Border Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e5e8ef',
				'settings' => 'mahic_mobile_sidebar_menu_brdrcolor',
				'label' => esc_attr__( 'Mobile Sidebar Menu Border Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for border color.', 'mahic-core' ),
				'section' => 'mahic_header_mobile_sidebar_menu_style_section',
			)
		);
		
		/*======  Mobile Sidebar Menu Copyright Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_mobile_sidebar_menu_copyright_color',
				'label' => esc_attr__( 'Mobile Sidebar Menu Copyright Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'mahic-core' ),
				'section' => 'mahic_header_mobile_sidebar_menu_style_section',
			)
		);
	
		

	/*====== SHOP ====================================================================================*/
		/*====== Shop Panels ======*/
		Kirki::add_panel (
			'mahic_shop_panel',
			array(
				'title' => esc_html__( 'Shop Settings', 'mahic-core' ),
				'description' => esc_html__( 'You can customize the shop from this panel.', 'mahic-core' ),
			)
		);

		$sections = array (
			'shop_general' => array(
				esc_attr__( 'General', 'mahic-core' ),
				esc_attr__( 'You can customize shop settings.', 'mahic-core' )
			),
			
			'shop_single' => array(
				esc_attr__( 'Product Detail', 'mahic-core' ),
				esc_attr__( 'You can customize the product single settings.', 'mahic-core' )
			),
			
			'shop_banner' => array(
				esc_attr__( 'Banner', 'mahic-core' ),
				esc_attr__( 'You can customize the banner.', 'mahic-core' )
			),
			
			'mobile_menu' => array(
				esc_attr__( 'Mobile Bottom Menu Style ', 'mahic-core' ),
				esc_attr__( 'You can customize the mobile menu.', 'mahic-core' )
			),

			'my_account' => array(
				esc_attr__( 'My Account', 'mahic-core' ),
				esc_attr__( 'You can customize the my account page.', 'mahic-core' )
			),

			'free_shipping_bar' => array(
				esc_attr__( 'Free Shipping Bar ', 'mahic-core' ),
				esc_attr__( 'You can customize the free shipping bar settings.', 'mahic-core' )
			),
			
		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'mahic_shop_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'mahic_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}
		
		/*====== Shop Layouts ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'mahic_shop_layout',
				'label' => esc_attr__( 'Layout', 'mahic' ),
				'description' => esc_attr__( 'You can choose a layout for the shop.', 'mahic' ),
				'section' => 'mahic_shop_general_section',
				'default' => 'left-sidebar',
				'choices' => array(
					'left-sidebar' => esc_attr__( 'Left Sidebar', 'mahic' ),
					'full-width' => esc_attr__( 'Full Width', 'mahic' ),
					'right-sidebar' => esc_attr__( 'Right Sidebar', 'mahic' ),
				),
			)
		);

		/*====== Shop Width ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'mahic_shop_width',
				'label' => esc_attr__( 'Shop Page Width', 'mahic' ),
				'description' => esc_attr__( 'You can choose a layout for the shop page.', 'mahic' ),
				'section' => 'mahic_shop_general_section',
				'default' => 'boxed',
				'choices' => array(
					'boxed' => esc_attr__( 'Boxed', 'mahic' ),
					'wide' => esc_attr__( 'Wide', 'mahic' ),
				),
			)
		);

		mahic_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'mahic_product_box_type',
			'label'       => esc_html__( 'Shop Product Box Type', 'mahic-core' ),
			'section'     => 'mahic_shop_general_section',
			'default'     => 'type1',
			'priority'    => 10,
			'choices'     => array(
				'type1' => esc_attr__( 'Type 1', 'mahic-core' ),
				'type2' => esc_attr__( 'Type 2', 'mahic-core' ),
				'type3' => esc_attr__( 'Type 3', 'mahic-core' ),
				'type4' => esc_attr__( 'Type 4', 'mahic-core' ),
			),
			) 
		);

		mahic_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'mahic_paginate_type',
			'label'       => esc_html__( 'Pagination Type', 'mahic-core' ),
			'section'     => 'mahic_shop_general_section',
			'default'     => 'default',
			'priority'    => 10,
			'choices'     => array(
				'default' => esc_attr__( 'Default', 'mahic-core' ),
				'loadmore' => esc_attr__( 'Load More', 'mahic-core' ),
				'infinite' => esc_attr__( 'Infinite', 'mahic-core' ),
			),
			) 
		);

		/*====== Product Box Gallery Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_product_box_gallery',
				'label' => esc_attr__( 'Product Gallery', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable gallery on the product box.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Ajax on Shop Page ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_ajax_on_shop',
				'label' => esc_attr__( 'Ajax on Shop Page', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable Ajax for the shop page.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Recently Viewed Products ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_recently_viewed_products',
				'label' => esc_attr__( 'Recently Viewed Products', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable Recently Viewed Products.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Grid-List Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_grid_list_view',
				'label' => esc_attr__( 'Grid List View', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable grid list view on shop page.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Perpage Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_perpage_view',
				'label' => esc_attr__( 'Perpage View', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable perpage view on shop page.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Atrribute Swatches ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_attribute_swatches',
				'label' => esc_attr__( 'Attribute Swatches', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable the attribute types (Color - Button - Images).', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Quick View Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_quick_view_button',
				'label' => esc_attr__( 'Quick View Button', 'mahic' ),
				'description' => esc_attr__( 'You can choose status of the quick view button.', 'mahic' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Wishlist Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_wishlist_button',
				'label' => esc_attr__( 'Custom Wishlist Button', 'mahic-core' ),
				'description' => esc_attr__( 'You can choose status of the wishlist button.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Shop Compare Toggle  ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_compare_button',
				'label' => esc_attr__( 'Compare', 'mahic' ),
				'description' => esc_attr__( 'You can choose status of the compare button.', 'mahic' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Ajax Notice Shop ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_shop_notice_ajax_addtocart',
				'label' => esc_attr__( 'Ajax Notice', 'mahic' ),
				'description' => esc_attr__( 'You can choose status of the ajax notice feature.', 'mahic' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Product Badge Tab ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_product_badge_tab',
				'label' => esc_attr__( 'Product Badge Tab', 'mahic-core' ),
				'description' => esc_attr__( 'You can choose status of the product badge tab.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Remove All Button ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_remove_all_button',
				'label' => esc_attr__( 'Remove All Button in cart page', 'mahic-core' ),
				'description' => esc_attr__( 'You can choose status of the remove all button.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Mobile Bottom Menu======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_mobile_bottom_menu',
				'label' => esc_attr__( 'Mobile Bottom Menu', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable the bottom menu on mobile.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Mobile Bottom Menu Edit Toggle======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_mobile_bottom_menu_edit_toggle',
				'label' => esc_attr__( 'Mobile Bottom Menu Edit', 'mahic' ),
				'description' => esc_attr__( 'Edit the mobile bottom menu.', 'mahic' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_mobile_bottom_menu',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
				
			)
			
		);
		
		/*====== Mobile Menu Repeater ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'mahic_mobile_bottom_menu_edit',
				'label' => esc_attr__( 'Mobile Bottom Menu Edit', 'mahic-core' ),
				'description' => esc_attr__( 'Edit the mobile bottom menu.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'required' => array(
					array(
					  'setting'  => 'mahic_mobile_bottom_menu_edit_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
				'fields' => array(
					'mobile_menu_type' => array(
						'type' => 'select',
						'label' => esc_attr__( 'Select Type', 'mahic' ),
						'description' => esc_attr__( 'You can select a type', 'mahic' ),
						'default' => 'default',
						'choices' => array(
							'default' => esc_attr__( 'Default', 'mahic-core' ),
							'search' => esc_attr__( 'Search', 'mahic-core' ),
							'filter' => esc_attr__( 'Filter', 'mahic-core' ),
							'category' => esc_attr__( 'category', 'mahic-core' ),
						),
					),
				
					'mobile_menu_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Icon', 'mahic' ),
						'description' => esc_attr__( 'You can set an icon. for example; "store"', 'mahic' ),
					),
					'mobile_menu_text' => array(
						'type' => 'text',
						'label' => esc_attr__( ' Text', 'mahic' ),
						'description' => esc_attr__( 'You can enter a text.', 'mahic' ),
					),
					'mobile_menu_url' => array(
						'type' => 'text',
						'label' => esc_attr__( 'URL', 'mahic-core' ),
						'description' => esc_attr__( 'You can set url for the item.', 'mahic-core' ),
					),
				),
				
			)
		);

		/*====== Catalog Mode - Disable Add to Cart ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_catalog_mode',
				'label' => esc_attr__( 'Catalog Mode', 'mahic-core' ),
				'description' => esc_attr__( 'Disable Add to Cart button on the shop page.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Stock Quantity ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_stock_quantity',
				'label' => esc_attr__( 'Stock Quantity', 'mahic' ),
				'description' => esc_attr__( 'Show stock quantity on the label.', 'mahic' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Product Min/Max Quantity ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_min_max_quantity',
				'label' => esc_attr__( 'Min/Max Quantity', 'mahic-core' ),
				'description' => esc_attr__( 'Enable the additional quantity setting fields in product detail page.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Category Description ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_category_description_after_content',
				'label' => esc_attr__( 'Category Desc After Content', 'mahic-core' ),
				'description' => esc_attr__( 'Add the category description after the products.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Min Order Amount ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_min_order_amount_toggle',
				'label' => esc_attr__( 'Min Order Amount', 'mahic-core' ),
				'description' => esc_attr__( 'Enable Min Order Amount.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Min Order Amount Value ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_min_order_amount_value',
				'label' => esc_attr__( 'Min Order Value', 'mahic-core' ),
				'description' => esc_attr__( 'Set amount to specify a minimum order value.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'mahic_min_order_amount_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Product Image Size ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'dimensions',
				'settings' => 'mahic_product_image_size',
				'label' => esc_attr__( 'Product Image Size', 'mahic-core' ),
				'description' => esc_attr__( 'You can set size of the product image for the shop page.', 'mahic-core' ),
				'section' => 'mahic_shop_general_section',
				'default' => array(
					'width' => '',
					'height' => '',
				),
			)
		);

		/*====== Shop Single Image Column ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'mahic_shop_single_image_column',
				'label'       => esc_html__( 'Image Column', 'mahic-core' ),
				'section'     => 'mahic_shop_single_section',
				'default'     => 6,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 3,
					'max'  => 12,
					'step' => 1,
				],
			)
		);

		/*====== Shop Single Image Zoom  ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_single_image_zoom',
				'label' => esc_attr__( 'Image Zoom', 'mahic-core' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Shop Single Ajax Add To Cart ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_shop_single_ajax_addtocart',
				'label' => esc_attr__( 'Ajax Add to Cart', 'mahic' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);

		/*======  Sticky Single Cart ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_single_sticky_cart',
				'label' => esc_attr__( 'Sticky Add to Cart', 'mahic-core' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Mobile Sticky Single Cart ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_mobile_single_sticky_cart',
				'label' => esc_attr__( 'Mobile Sticky Add to Cart', 'mahic-core' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Product360 View ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_shop_single_product360',
				'label' => esc_attr__( 'Product360 View', 'mahic' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Order on WhatsApp ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_shop_single_orderonwhatsapp',
				'label' => esc_attr__( 'Order on WhatsApp', 'mahic' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Move Review Tab ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_shop_single_review_tab_move',
				'label' => esc_attr__( 'Move Review Tab', 'mahic' ),
				'description' => esc_attr__( 'Move the review tab out of tabs', 'mahic-core' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Buy Now Single ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_shop_single_buy_now',
				'label' => esc_attr__( 'Buy Now Button', 'mahic-core' ),
				'description' => esc_attr__( 'Disable or Enable Buy Now button.', 'mahic-core' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);
		
		/*====== Order on WhatsApp Number======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_shop_single_whatsapp_number',
				'label' => esc_attr__( 'WhatsApp Number', 'mahic' ),
				'description' => esc_attr__( 'You can add a phone number for order on WhatsApp.', 'mahic' ),
				'section' => 'mahic_shop_single_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'mahic_shop_single_orderonwhatsapp',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Shop Single Social Share ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_shop_social_share',
				'label' => esc_attr__( 'Social Share (Product Detail)', 'mahic' ),
				'section' => 'mahic_shop_single_section',
				'default' => '0',
			)
		);
		
		/*====== Shop Single Social Share ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'multicheck',
				'settings'    => 'mahic_shop_single_share',
				'section'     => 'mahic_shop_single_section',
				'default'     => array('facebook','twitter', 'pinterest', 'linkedin', 'whatsapp'  ),
				'priority'    => 10,
				'choices'     => [
					'facebook'  => esc_html__( 'Facebook', 	'mahic-core' ),
					'twitter' 	=> esc_html__( 'Twitter', 	'mahic-core' ),
					'pinterest' => esc_html__( 'Pinterest', 'mahic-core' ),
					'linkedin'  => esc_html__( 'Linkedin', 	'mahic-core' ),
					'whatsapp'  => esc_html__( 'Whatsapp', 	'mahic-core' ),
				],
				'required' => array(
					array(
					  'setting'  => 'mahic_shop_social_share',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Product Gallery Columns ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'mahic_shop_single_gallery_columns',
				'label' => esc_attr__( 'Gallery Columns', 'mahic' ),
				'section' => 'mahic_shop_single_section',
				'default' => '7',
				'choices' => array(
					'8' => esc_attr__( '8 Columns', 'mahic' ),
					'7' => esc_attr__( '7 Columns', 'mahic' ),
					'6' => esc_attr__( '6 Columns', 'mahic' ),
					'5' => esc_attr__( '5 Columns', 'mahic' ),
					'4' => esc_attr__( '4 Columns', 'mahic' ),
					'3' => esc_attr__( '3 Columns', 'mahic' ),
					'2' => esc_attr__( '2 Columns', 'mahic' ),
				),
			)
		);

		/*====== Product Related Post Column ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'mahic_shop_related_post_column',
				'label' => esc_attr__( 'Related Post Column', 'mahic' ),
				'description' => esc_attr__( 'You can control related post column with this option.', 'mahic' ),
				'section' => 'mahic_shop_single_section',
				'default' => '4',
				'choices' => array(
					'6' => esc_attr__( '6 Columns', 'mahic' ),
					'5' => esc_attr__( '5 Columns', 'mahic' ),
					'4' => esc_attr__( '4 Columns', 'mahic' ),
					'3' => esc_attr__( '3 Columns', 'mahic' ),
					'2' => esc_attr__( '2 Columns', 'mahic' ),
				),
			)
		);

		/*====== Re-Order Product Detail ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'sortable',
				'settings' => 'mahic_shop_single_reorder',
				'label' => esc_attr__( 'Re-order Product Summary', 'mahic-core' ),
				'description' => esc_attr__( 'Please save the changes and refresh the page once. Live preview is not available for the option.', 'mahic-core' ),
				'section' => 'mahic_shop_single_section',
				'default'     => [
					'woocommerce_template_single_title',
					'woocommerce_template_single_rating',
					'woocommerce_template_single_price',
					'woocommerce_template_single_add_to_cart',
					'mahic_people_added_in_cart',
					'woocommerce_template_single_meta',
					'mahic_social_share',
					'woocommerce_template_single_excerpt',
				],
				'choices'     => [
					'woocommerce_template_single_title' => esc_html__( 'Title', 'mahic-core' ),
					'woocommerce_template_single_rating' => esc_html__( 'Rating', 'mahic-core' ),
					'woocommerce_template_single_price' => esc_html__( 'Price', 'mahic-core' ),
					'woocommerce_template_single_add_to_cart' => esc_html__( 'Add to Cart', 'mahic-core' ),
					'mahic_people_added_in_cart' => esc_html__( 'People Added', 'mahic-core' ),
					'woocommerce_template_single_meta' => esc_html__( 'Meta', 'mahic-core' ),
					'mahic_social_share' => esc_html__( 'Share', 'kirki' ),
					'woocommerce_template_single_excerpt' => esc_html__( 'Excerpt', 'mahic-core' ),
					'mahic_product_stock_progress_bar' => esc_html__( 'Progress Bar', 'mahic-core' ),
					'mahic_product_time_countdown' => esc_html__( 'Time Countdown', 'mahic-core' ),
				],
			)
		);
		
		/*====== Shop Top Banner Title ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'mahic_shop_top_banner_title',
				'label' => esc_attr__( 'Set Title', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a title.', 'mahic-core' ),
				'section' => 'mahic_shop_banner_section',
				'default' => '',
			)
		);
		
		/*====== Shop Top Banner Subtitle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'mahic_shop_top_banner_subtitle',
				'label' => esc_attr__( 'Set Subtitle', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a subtitle.', 'mahic-core' ),
				'section' => 'mahic_shop_banner_section',
				'default' => '',
			)
		);
		
		/*====== Shop Top Banner Desc ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_shop_top_banner_desc',
				'label' => esc_attr__( 'Description', 'mahic-core' ),
				'description' => esc_attr__( 'Add a description.', 'mahic-core' ),
				'section' => 'mahic_shop_banner_section',
				'default' => '',
			)
		);

		/*====== Shop Top Banner Button Text ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_shop_top_banner_button_text',
				'label' => esc_attr__( 'Button Text', 'mahic-core' ),
				'description' => esc_attr__( 'Set a text for the button', 'mahic-core' ),
				'section' => 'mahic_shop_banner_section',
				'default' => 'Shop',
			)
		);

		/*====== Shop Top Banner URL ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_shop_top_banner_button_url',
				'label' => esc_attr__( 'Button URL', 'mahic-core' ),
				'description' => esc_attr__( 'Set an url for the button', 'mahic-core' ),
				'section' => 'mahic_shop_banner_section',
				'default' => '#',
			)
		);
		

		/*====== Banner Repeater 3 Columns ======*/
		add_action( 'init', function() {
			mahic_customizer_add_field (
				array(
					'type' => 'repeater',
					'settings' => 'mahic_shop_banner_module',
					'label' => esc_attr__( 'Shop Banner', 'mahic-core' ),
					'description' => esc_attr__( 'You can set banner.', 'mahic-core' ),
					'section' => 'mahic_shop_banner_section',
					'fields' => array(
						
						'banner_image' =>  array(
							'type' => 'image',
							'label' => esc_attr__( 'Image', 'mahic-core' ),
							'description' => esc_attr__( 'You can upload an image.', 'mahic-core' ),
						),
						
						'banner_title' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Set Title', 'mahic-core' ),
							'description' => esc_attr__( 'You can set a title.', 'mahic-core' ),
						),
						
						'banner_subtitle' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Set Subtitle', 'mahic-core' ),
							'description' => esc_attr__( 'You can set a subtitle.', 'mahic-core' ),
						),
			
						'banner_desc' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Description', 'mahic-core' ),
							'description' => esc_attr__( 'Add a description.', 'mahic-core' ),
						),
						
						'banner_regular_price' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Regular Price', 'mahic-core' ),
							'description' => esc_attr__( 'Add a regular price.', 'mahic-core' ),
						),
						
						'banner_sale_price' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Sale Price', 'mahic-core' ),
							'description' => esc_attr__( 'Add a sale price.', 'mahic-core' ),
						),
						
						'banner_url' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Set URL', 'mahic-core' ),
							'description' => esc_attr__( 'Set an url for the banner', 'mahic-core' ),
						),
					),
				)
			);
		} );
		
		/*======  Mobile Menu Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_mobile_menu_bg_color',
				'label' => esc_attr__( 'Mobile Menu Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a Background.', 'mahic-core' ),
				'section' => 'mahic_mobile_menu_section',
			)
		);
		
		/*======  Mobile Menu Icon Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_mobile_menu_icon_color',
				'label' => esc_attr__( 'Mobile Menu Icon Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color.', 'mahic-core' ),
				'section' => 'mahic_mobile_menu_section',
			)
		);
		
		/*======  Mobile Menu Icon Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_mobile_menu_icon_hvrcolor',
				'label' => esc_attr__( 'Mobile Menu Icon Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color.', 'mahic-core' ),
				'section' => 'mahic_mobile_menu_section',
			)
		);
		
		/*======  Mobile Menu Font Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_mobile_menu_color',
				'label' => esc_attr__( 'Mobile Menu Font Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color.', 'mahic-core' ),
				'section' => 'mahic_mobile_menu_section',
			)
		);
		
		/*======  Mobile Menu Font Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_mobile_menu_hvr_color',
				'label' => esc_attr__( 'Mobile Menu Font Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color.', 'mahic-core' ),
				'section' => 'mahic_mobile_menu_section',
			)
		);
		
		/*====== Mobile Menu Font Style ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_mobile_menu_size',
				'label'       => esc_attr__( 'Mobile Menu Font Style', 'mahic-core' ),
				'section'     => 'mahic_mobile_menu_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '9px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.mobile-bottom-menu .mobile-menu ul li a span',
					],
				],		
			)
		);
		
		/*====== My Account Layouts ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'mahic_my_account_layout',
				'label' => esc_attr__( 'Layout', 'mahic-core' ),
				'description' => esc_attr__( 'You can choose a layout for the login form.', 'mahic-core' ),
				'section' => 'mahic_my_account_section',
				'default' => 'default',
				'choices' => array(
					'default' => esc_attr__( 'Default', 'mahic-core' ),
					'logintab' => esc_attr__( 'Login Tab', 'mahic-core' ),
				),
			)
		);

		/*====== Registration Form First Name ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'mahic_registration_first_name',
				'label' => esc_attr__( 'Register - First Name', 'mahic-core' ),
				'section' => 'mahic_my_account_section',
				'default' => 'hidden',
				'choices' => array(
					'hidden' => esc_attr__( 'Hidden', 'mahic-core' ),
					'visible' => esc_attr__( 'Visible', 'mahic-core' ),
					'optional' => esc_attr__( 'Optional', 'mahic-core' ),
				),
			)
		);
		
		/*====== Registration Form Last Name ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'mahic_registration_last_name',
				'label' => esc_attr__( 'Register - Last Name', 'mahic-core' ),
				'section' => 'mahic_my_account_section',
				'default' => 'hidden',
				'choices' => array(
					'hidden' => esc_attr__( 'Hidden', 'mahic-core' ),
					'visible' => esc_attr__( 'Visible', 'mahic-core' ),
					'optional' => esc_attr__( 'Optional', 'mahic-core' ),
				),
			)
		);
		
		/*====== Registration Form Billing Company ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'mahic_registration_billing_company',
				'label' => esc_attr__( 'Register - Billing Company', 'mahic-core' ),
				'section' => 'mahic_my_account_section',
				'default' => 'hidden',
				'choices' => array(
					'hidden' => esc_attr__( 'Hidden', 'mahic-core' ),
					'visible' => esc_attr__( 'Visible', 'mahic-core' ),
					'optional' => esc_attr__( 'Optional', 'mahic-core' ),
				),
			)
		);
		
		/*====== Registration Form Billing Phone ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'mahic_registration_billing_phone',
				'label' => esc_attr__( 'Register - Billing Phone', 'mahic-core' ),
				'section' => 'mahic_my_account_section',
				'default' => 'hidden',
				'choices' => array(
					'hidden' => esc_attr__( 'Hidden', 'mahic-core' ),
					'visible' => esc_attr__( 'Visible', 'mahic-core' ),
					'optional' => esc_attr__( 'Optional', 'mahic-core' ),
				),
			)
		);

		/*====== Ajax Login-Register ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_ajax_login_form',
				'label' => esc_attr__( 'Activate Ajax for Login Form', 'mahic-core' ),
				'section' => 'mahic_my_account_section',
				'default' => '0',
			)
		);


		/*====== Redirect URL After Login ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'url',
				'settings' => 'mahic_redirect_url_after_login',
				'label' => esc_attr__( 'Redirect URL After Login', 'mahic-core' ),
				'section' => 'mahic_my_account_section',
				'default' => '',
			)
		);

	/*====== Free Shipping Settings =======================================================*/
	
		/*====== Free Shipping ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_free_shipping',
				'label' => esc_attr__( 'Free shipping bar', 'mahic-core' ),
				'section' => 'mahic_free_shipping_bar_section',
				'default' => '0',
			)
		);
		
		/*====== Free Shipping Goal Amount ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'shipping_progress_bar_amount',
				'label' => esc_attr__( 'Goal Amount', 'mahic-core' ),
				'description' => esc_attr__( 'Amount to reach 100% defined in your currency absolute value. For example: 300', 'mahic-core' ),
				'section' => 'mahic_free_shipping_bar_section',
				'default' => '100',
				'required' => array(
					array(
					  'setting'  => 'mahic_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Location Cart Page ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'shipping_progress_bar_location_card_page',
				'label' => esc_attr__( 'Cart page', 'mahic-core' ),
				'section' => 'mahic_free_shipping_bar_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Location Mini cart ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'shipping_progress_bar_location_mini_cart',
				'label' => esc_attr__( 'Mini cart', 'mahic-core' ),
				'section' => 'mahic_free_shipping_bar_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Location Checkout page ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'shipping_progress_bar_location_checkout',
				'label' => esc_attr__( 'Checkout page', 'mahic-core' ),
				'section' => 'mahic_free_shipping_bar_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'mahic_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Message Initial ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'shipping_progress_bar_message_initial',
				'label' => esc_attr__( 'Initial Message', 'mahic-core' ),
				'description' => esc_attr__( 'Message to show before reaching the goal. Use shortcode [remainder] to display the amount left to reach the minimum.', 'mahic-core' ),
				'section' => 'mahic_free_shipping_bar_section',
				'default' => 'Add [remainder] to cart and get free shipping!',
				'required' => array(
					array(
					  'setting'  => 'mahic_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Message Success ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'shipping_progress_bar_message_success',
				'label' => esc_attr__( 'Success message', 'mahic-core' ),
				'description' => esc_attr__( 'Message to show after reaching 100%.', 'mahic-core' ),
				'section' => 'mahic_free_shipping_bar_section',
				'default' => 'Your order qualifies for free shipping!',
				'required' => array(
					array(
					  'setting'  => 'mahic_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

	/*====== Blog Settings =======================================================*/
		/*====== Layouts ======*/
		
		mahic_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'mahic_blog_layout',
				'label' => esc_attr__( 'Layout', 'mahic' ),
				'description' => esc_attr__( 'You can choose a layout.', 'mahic' ),
				'section' => 'mahic_blog_settings_section',
				'default' => 'right-sidebar',
				'choices' => array(
					'left-sidebar' => esc_attr__( 'Left Sidebar', 'mahic' ),
					'full-width' => esc_attr__( 'Full Width', 'mahic' ),
					'right-sidebar' => esc_attr__( 'Right Sidebar', 'mahic' ),
				),
			)
		);
		
		/*====== Main color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#041e42',
				'settings' => 'mahic_main_color',
				'label' => esc_attr__( 'Main Color', 'mahic' ),
				'description' => esc_attr__( 'You can customize the main color.', 'mahic' ),
				'section' => 'mahic_main_color_section',
			)
		);

		/*====== Secondary color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_second_color',
				'label' => esc_attr__( 'Second Color', 'mahic' ),
				'description' => esc_attr__( 'You can customize the secondary color.', 'mahic' ),
				'section' => 'mahic_main_color_section',
			)
		);
		
		/*====== Color Link======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#0070dc',
				'settings' => 'mahic_color_link',
				'label' => esc_attr__( 'Color Link', 'mahic-core' ),
				'description' => esc_attr__( 'You can customize the color link.', 'mahic-core' ),
				'section' => 'mahic_main_color_section',
			)
		);
		
		/*====== Color Shop Button======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#00a046',
				'settings' => 'mahic_color_shop_button',
				'label' => esc_attr__( 'Color Shop Button', 'mahic-core' ),
				'description' => esc_attr__( 'You can customize the color shop button.', 'mahic-core' ),
				'section' => 'mahic_main_color_section',
			)
		);
		
		/*====== Color Shop Button Active======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#037535',
				'settings' => 'mahic_color_shop_button_active',
				'label' => esc_attr__( 'Color Shop Button Active', 'mahic-core' ),
				'description' => esc_attr__( 'You can customize the color shop button.', 'mahic-core' ),
				'section' => 'mahic_main_color_section',
			)
		);
		
		/*====== Color Danger ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ef262c',
				'settings' => 'mahic_color_danger',
				'label' => esc_attr__( 'Color Danger', 'mahic' ),
				'description' => esc_attr__( 'You can customize the color danger.', 'mahic' ),
				'section' => 'mahic_main_color_section',
			)
		);
		
		/*====== Color Warning======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ff5c00',
				'settings' => 'mahic_color_warning',
				'label' => esc_attr__( 'Color Warning', 'mahic-core' ),
				'description' => esc_attr__( 'You can customize the color warning.', 'mahic-core' ),
				'section' => 'mahic_main_color_section',
			)
		);
		
		/*====== Color Success======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#00a046',
				'settings' => 'mahic_color_success',
				'label' => esc_attr__( 'Color Success', 'mahic-core' ),
				'description' => esc_attr__( 'You can customize the color success.', 'mahic-core' ),
				'section' => 'mahic_main_color_section',
			)
		);
		
		/*====== Color Light======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#f2f3f5',
				'settings' => 'mahic_color_light',
				'label' => esc_attr__( 'Color Light', 'mahic-core' ),
				'description' => esc_attr__( 'You can customize the color light.', 'mahic-core' ),
				'section' => 'mahic_main_color_section',
			)
		);

	/*====== Elementor Templates =======================================================*/
		/*====== Before Shop Elementor Templates ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'mahic_before_main_shop_elementor_template',
				'label'       => esc_html__( 'Before Shop Elementor Template', 'mahic-core' ),
				'section'     => 'mahic_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'mahic-core' ),
				'choices'     => mahic_get_elementorTemplates('section'),
				
			)
		);
		
		/*====== After Shop Elementor Templates ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'mahic_after_main_shop_elementor_template',
				'label'       => esc_html__( 'After Shop Elementor Template', 'mahic-core' ),
				'section'     => 'mahic_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'mahic-core' ),
				'choices'     => mahic_get_elementorTemplates('section'),
				
			)
		);
		
		/*====== Before Header Elementor Templates ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'mahic_before_main_header_elementor_template',
				'label'       => esc_html__( 'Before Header Elementor Template', 'mahic-core' ),
				'section'     => 'mahic_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'mahic-core' ),
				'choices'     => mahic_get_elementorTemplates('section'),
				
			)
		);
	
		/*====== After Header Elementor Templates ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'mahic_after_main_header_elementor_template',
				'label'       => esc_html__( 'After Header Elementor Template', 'mahic-core' ),
				'section'     => 'mahic_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'mahic-core' ),
				'choices'     => mahic_get_elementorTemplates('section'),
				
			)
		);
		
		/*====== Before Footer Elementor Template ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'mahic_before_main_footer_elementor_template',
				'label'       => esc_html__( 'Before Footer Elementor Template', 'mahic-core' ),
				'section'     => 'mahic_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'mahic-core' ),
				'choices'     => mahic_get_elementorTemplates('section'),
				
			)
		);
		
		/*====== After Footer Elementor  Template ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'mahic_after_main_footer_elementor_template',
				'label'       => esc_html__( 'After Footer Elementor Templates', 'mahic-core' ),
				'section'     => 'mahic_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'mahic-core' ),
				'choices'     => mahic_get_elementorTemplates('section'),
				
			)
		);

		/*====== Templates Repeater For each category ======*/
		add_action( 'init', function() {
			mahic_customizer_add_field (
				array(
					'type' => 'repeater',
					'settings' => 'mahic_elementor_template_each_shop_category',
					'label' => esc_attr__( 'Template For Categories', 'mahic-core' ),
					'description' => esc_attr__( 'You can set template for each category.', 'mahic-core' ),
					'section' => 'mahic_elementor_templates_section',
					'fields' => array(
						
						'category_id' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Select Category', 'mahic-core' ),
							'description' => esc_html__( 'Set a category', 'mahic-core' ),
							'priority'    => 10,
							'default'     => '',
							'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'product_cat') )
						),
						
						'mahic_before_main_shop_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Shop Elementor Template', 'mahic-core' ),
							'choices'     => mahic_get_elementorTemplates('section'),
							'default'     => '',
							'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'mahic-core' ),
						),
						
						'mahic_after_main_shop_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Shop Elementor Template', 'mahic-core' ),
							'choices'     => mahic_get_elementorTemplates('section'),
						),
						
						'mahic_before_main_header_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Header Elementor Template', 'mahic-core' ),
							'choices'     => mahic_get_elementorTemplates('section'),
						),
						
						'mahic_after_main_header_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Header Elementor Template', 'mahic-core' ),
							'choices'     => mahic_get_elementorTemplates('section'),
						),
						
						'mahic_before_main_footer_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Footer Elementor Template', 'mahic-core' ),
							'choices'     => mahic_get_elementorTemplates('section'),
						),
						
						'mahic_after_main_footer_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Footer Elementor Template', 'mahic-core' ),
							'choices'     => mahic_get_elementorTemplates('section'),
						),
						

					),
				)
			);
		} );

		/*====== Map Settings ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_mapapi',
				'label' => esc_attr__( 'Google Map Api key', 'mahic' ),
				'description' => esc_attr__( 'Add your google map api key', 'mahic' ),
				'section' => 'mahic_map_settings_section',
				'default' => '',
			)
		);
		
	/*====== Footer ======*/
		/*====== Footer Panels ======*/
		Kirki::add_panel (
			'mahic_footer_panel',
			array(
				'title' => esc_html__( 'Footer Settings', 'mahic' ),
				'description' => esc_html__( 'You can customize the footer from this panel.', 'mahic' ),
			)
		);

		$sections = array (
			'footer_subscribe' => array(
				esc_attr__( 'Subscribe', 'mahic' ),
				esc_attr__( 'You can customize the subscribe area.', 'mahic' )
			),
			
			'footer_general' => array(
				esc_attr__( 'Footer General', 'mahic' ),
				esc_attr__( 'You can customize the footer settings.', 'mahic-core' )
			),
			
			'footer_style' => array(
				esc_attr__( 'Footer Style', 'mahic-core' ),
				esc_attr__( 'You can customize the footer settings.', 'mahic-core' )
			),
			
		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'mahic_footer_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'mahic_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}

		
		/*====== Subcribe Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_footer_subscribe_area',
				'label' => esc_attr__( 'Subcribe', 'mahic' ),
				'description' => esc_attr__( 'Disable or Enable subscribe section.', 'mahic' ),
				'section' => 'mahic_footer_subscribe_section',
				'default' => '0',
			)
		);
		
		/*====== Subcribe FORM ID======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_footer_subscribe_formid',
				'label' => esc_attr__( 'Subscribe Form Id.', 'mahic' ),
				'description' => esc_attr__( 'You can find the form id in Dashboard > Mailchimp For Wp > Form.', 'mahic' ),
				'section' => 'mahic_footer_subscribe_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'mahic_footer_subscribe_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subscribe Title ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_footer_subscribe_title',
				'label' => esc_attr__( 'Title', 'mahic' ),
				'description' => esc_attr__( 'You can set text for subscribe section.', 'mahic' ),
				'section' => 'mahic_footer_subscribe_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'mahic_footer_subscribe_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subscribe Subtitle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'mahic_footer_subscribe_subtitle',
				'label' => esc_attr__( 'Subtitle', 'mahic' ),
				'description' => esc_attr__( 'You can set text for subscribe section.', 'mahic' ),
				'section' => 'mahic_footer_subscribe_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'mahic_footer_subscribe_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subscribe Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#041e42',
				'settings' => 'mahic_subscribe_bg',
				'label' => esc_attr__( 'Subscribe Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe  Title Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_subscribe_title_color',
				'label' => esc_attr__( 'Subscribe Title Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe Title Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_subscribe_title_hvrcolor',
				'label' => esc_attr__( 'Subscribe Title Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe  Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_subscribe_subtitle_color',
				'label' => esc_attr__( 'Subscribe Subtitle Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe Subtitle Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_subscribe_subtitle_hvrcolor',
				'label' => esc_attr__( 'Subscribe Subtitle Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe  Subtitle Strong Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_subscribe_subtitle_strong_color',
				'label' => esc_attr__( 'Subscribe Subtitle Strong Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe Subtitle Strong Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffbd27',
				'settings' => 'mahic_subscribe_subtitle_strong_hvrcolor',
				'label' => esc_attr__( 'Subscribe Subtitle Strong Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe  Title Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_subscribe_title_size',
				'label'       => esc_attr__( 'Subscribe Title Typography', 'mahic-core' ),
				'section'     => 'mahic_footer_subscribe_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '22px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-footer .footer-newsletter .site-newsletter .entry-title',
					],
				],		
			)
		);
		
		/*====== Subscribe  Subtitle Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_subscribe_subtitle_size',
				'label'       => esc_attr__( 'Subscribe Subtitle Typography', 'mahic-core' ),
				'section'     => 'mahic_footer_subscribe_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '14px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-footer .footer-newsletter .site-newsletter .entry-description',
					],
				],		
			)
		);

		/*====== Footer Social List ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'mahic_footer_social_list',
				'label' => esc_attr__( 'Social List', 'mahic-core' ),
				'description' => esc_attr__( 'You can set social icons.', 'mahic-core' ),
				'section' => 'mahic_footer_general_section',
				'fields' => array(
					'social_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Icon', 'mahic-core' ),
						'description' => esc_attr__( 'You can set an icon. for example; "facebook"', 'mahic-core' ),
					),

					'social_url' => array(
						'type' => 'text',
						'label' => esc_attr__( 'URL', 'mahic-core' ),
						'description' => esc_attr__( 'You can set url for the item.', 'mahic-core' ),
					),

				),
			)
		);
		
		/*====== Footer Tags Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_footer_tags_toggle',
				'label' => esc_attr__( 'Footer Tags', 'mahic' ),
				'description' => esc_attr__( 'Disable or Enable the products tags.', 'mahic' ),
				'section' => 'mahic_footer_general_section',
				'default' => '0',
			)
		);
		
		/*====== Back to top  ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_scroll_to_top',
				'label' => esc_attr__( 'Back To Top Button', 'mahic' ),
				'section' => 'mahic_footer_general_section',
				'default' => '0',
			)
		);
		
		/*====== Copyright ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'mahic_copyright',
				'label' => esc_attr__( 'Copyright', 'mahic' ),
				'description' => esc_attr__( 'You can set a copyright text for the footer.', 'mahic' ),
				'section' => 'mahic_footer_general_section',
				'default' => '',
			)
		);
		
		/*====== Payment Image ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'mahic_footer_payment_image',
				'label' => esc_attr__( 'Payment Image', 'mahic' ),
				'description' => esc_attr__( 'You can upload an image.', 'mahic' ),
				'section' => 'mahic_footer_general_section',
				'choices' => array(
					'save_as' => 'id',
				),
			)
		);

		/*====== Payment Image URL ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_footer_payment_image_url',
				'label' => esc_attr__( 'Set Payment URL', 'mahic-core' ),
				'description' => esc_attr__( 'Set an url for the payment image', 'mahic-core' ),
				'section' => 'mahic_footer_general_section',
				'default' => '#',
			)
		);

		/*====== Footer Column ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'mahic_footer_column',
				'label' => esc_attr__( 'Footer Column', 'mahic' ),
				'description' => esc_attr__( 'You can set footer column.', 'mahic' ),
				'section' => 'mahic_footer_general_section',
				'default' => '5columns',
				'choices' => array(
					'5columns' => esc_attr__( '5 Columns', 'mahic' ),
					'4columns' => esc_attr__( '4 Columns', 'mahic' ),
					'3columns' => esc_attr__( '3 Columns', 'mahic' ),
				),
			)
		);
		
		/*====== Footer Widget Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#f7f8f9',
				'settings' => 'mahic_featured_widget_bg_color',
				'label' => esc_attr__( 'Footer Widget Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Widget Title Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_featured_widget_title_color',
				'label' => esc_attr__( 'Footer Widget Title Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  Color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Widget Title Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_featured_widget_title_hvrcolor',
				'label' => esc_attr__( 'Footer Widget Title Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  Color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Widget Subtitle Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_featured_widget_subtitle_color',
				'label' => esc_attr__( 'Footer Widget Subtitle Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  Color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Widget Subtitle Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_featured_widget_subtitle_hvrcolor',
				'label' => esc_attr__( 'Footer Widget Subtitle Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  Color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_featured_bg_color',
				'label' => esc_attr__( 'Footer Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Border Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e5e8ec',
				'settings' => 'mahic_featured_border_color',
				'label' => esc_attr__( 'Footer Border Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  border.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Social Icon Background Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#d1d6dd',
				'settings' => 'mahic_footer_social_icon_bg',
				'label' => esc_attr__( 'Footer Social Icon Background Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Social Icon Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'mahic_footer_social_icon_color',
				'label' => esc_attr__( 'Footer Social Icon Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Tags Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_featured_tags_color',
				'label' => esc_attr__( 'Footer Tags Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  Color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Tags Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#021523',
				'settings' => 'mahic_featured_tags_hvrcolor',
				'label' => esc_attr__( 'Footer Tags Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  Color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Copyright Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_featured_copyright_color',
				'label' => esc_attr__( 'Footer Copyright Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  Color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Copyright Hover Color ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#818ea0',
				'settings' => 'mahic_featured_copyright_hvrcolor',
				'label' => esc_attr__( 'Footer Copyright Hover Color', 'mahic-core' ),
				'description' => esc_attr__( 'You can set a color for  Color.', 'mahic-core' ),
				'section' => 'mahic_footer_style_section',
			)
		);
		
		/*====== Footer Tags Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_footer_tags_size',
				'label'       => esc_attr__( 'Footer Tags Typography', 'mahic-core' ),
				'section'     => 'mahic_footer_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '13px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
					
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-footer .footer-details .site-details .tags li a ',
					],
				],
			)
		);
		
		/*====== Footer Copyright Typography ======*/
		mahic_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'mahic_footer_copyright_size',
				'label'       => esc_attr__( 'Footer Copyright Typography', 'mahic-core' ),
				'section'     => 'mahic_footer_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '12px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
					
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-footer .footer-copyright .site-copyright',
					],
				],
			)
		);
		
		
		/*====== Newsletter Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_newsletter_popup_toggle',
				'label' => esc_attr__( 'Enable Newsletter', 'mahic-core' ),
				'description' => esc_attr__( 'You can choose status of Newsletter Popup.', 'mahic-core' ),
				'section' => 'mahic_newsletter_settings_section',
				'default' => '0',
			)
		);
		
		/*====== Newsletter Type ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'mahic_newsletter_type',
				'label' => esc_attr__( 'Newsletter Type', 'mahic-core' ),
				'section' => 'mahic_newsletter_settings_section',
				'default' => 'type1',
				'choices' => array(
					'type1' => esc_attr__( 'Type 1', 'mahic-core' ),
					'type2' => esc_attr__( 'Type 2', 'mahic-core' ),
					'type3' => esc_attr__( 'Type 3', 'mahic-core' ),
				),
				'required' => array(
					array(
					  'setting'  => 'mahic_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Newsletter Image ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'mahic_newsletter_image',
				'label' => esc_attr__( 'Image', 'mahic-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'mahic-core' ),
				'section' => 'mahic_newsletter_settings_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'input_attrs' => array( 'class' => 'my_custom_class' ),

				'active_callback' => [
					[
					  'setting'  => 'mahic_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					],
					[
					  'setting'  => 'mahic_newsletter_type',
					  'operator' => '!=',
					  'value'    => 'type1',
					]
				],

			)
		);
		
		
		/*====== Newsletter Title ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_newsletter_popup_title',
				'label' => esc_attr__( 'Newsletter Title', 'mahic-core' ),
				'section' => 'mahic_newsletter_settings_section',
				'default' => 'Subscribe To Newsletter',
				'required' => array(
					array(
					  'setting'  => 'mahic_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Newsletter Subtitle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'mahic_newsletter_popup_subtitle',
				'label' => esc_attr__( 'Newsletter Subtitle', 'mahic-core' ),
				'section' => 'mahic_newsletter_settings_section',
				'default' => 'Subscribe to the mahic mailing list to receive updates on new arrivals, special offers and our promotions.',
				'required' => array(
					array(
					  'setting'  => 'mahic_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subcribe Popup FORM ID======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_newsletter_popup_formid',
				'label' => esc_attr__( 'Newsletter Form Id.', 'mahic-core' ),
				'description' => esc_attr__( 'You can find the form id in Dashboard > Mailchimp For Wp > Form.', 'mahic-core' ),
				'section' => 'mahic_newsletter_settings_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'mahic_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subcribe Popup Expire Date ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_newsletter_popup_expire_date',
				'label' => esc_attr__( 'Newsletter Expire Date', 'mahic-core' ),
				'section' => 'mahic_newsletter_settings_section',
				'default' => '15',
				'required' => array(
					array(
					  'setting'  => 'mahic_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== GDPR Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_gdpr_toggle',
				'label' => esc_attr__( 'Enable GDPR', 'mahic-core' ),
				'description' => esc_attr__( 'You can choose status of GDPR.', 'mahic-core' ),
				'section' => 'mahic_gdpr_settings_section',
				'default' => '0',
			)
		);

		/*====== GDPR Image======*/
		mahic_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'mahic_gdpr_image',
				'label' => esc_attr__( 'Image', 'mahic-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'mahic-core' ),
				'section' => 'mahic_gdpr_settings_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'required' => array(
					array(
					  'setting'  => 'mahic_gdpr_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== GDPR Text ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'mahic_gdpr_text',
				'label' => esc_attr__( 'GDPR Text', 'mahic-core' ),
				'section' => 'mahic_gdpr_settings_section',
				'default' => 'In order to provide you a personalized shopping experience, our site uses cookies. <br><a href="#">cookie policy</a>.',
				'required' => array(
					array(
					  'setting'  => 'mahic_gdpr_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== GDPR Expire Date ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_gdpr_expire_date',
				'label' => esc_attr__( 'GDPR Expire Date', 'mahic-core' ),
				'section' => 'mahic_gdpr_settings_section',
				'default' => '15',
				'required' => array(
					array(
					  'setting'  => 'mahic_gdpr_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== GDPR Button Text ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_gdpr_button_text',
				'label' => esc_attr__( 'GDPR Button Text', 'mahic-core' ),
				'section' => 'mahic_gdpr_settings_section',
				'default' => 'Accept Cookies',
				'required' => array(
					array(
					  'setting'  => 'mahic_gdpr_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Maintenance Toggle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'mahic_maintenance_toggle',
				'label' => esc_attr__( 'Enable Maintenance Mode', 'mahic-core' ),
				'description' => esc_attr__( 'You can choose status of Maintenance.', 'mahic-core' ),
				'section' => 'mahic_maintenance_settings_section',
				'default' => '0',
			)
		);
		
		/*====== Maintenance Title ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_maintenance_title',
				'label' => esc_attr__( 'Title', 'mahic-core' ),
				'section' => 'mahic_maintenance_settings_section',
				'default' => 'Coming',
				'active_callback' => [
					[
					  'setting'  => 'mahic_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],
			)
		);

		/*====== Maintenance Second Title ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_maintenance_second_title',
				'label' => esc_attr__( 'Second Title', 'mahic-core' ),
				'section' => 'mahic_maintenance_settings_section',
				'default' => 'Soon',
				'active_callback' => [
					[
					  'setting'  => 'mahic_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],
			)
		);
		
		/*====== Maintenance Subtitle ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'mahic_maintenance_subtitle',
				'label' => esc_attr__( 'Subtitle', 'mahic-core' ),
				'section' => 'mahic_maintenance_settings_section',
				'default' => 'Get ready! Something really cool is coming!',
				'active_callback' => [
					[
					  'setting'  => 'mahic_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],
			)
		);
		
		/*====== Maintenance Mailchimp FORM ID======*/
		mahic_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'mahic_maintenance_mailchimp_formid',
				'label' => esc_attr__( 'Mailchimp Form Id.', 'mahic-core' ),
				'description' => esc_attr__( 'You can find the form id in Dashboard > Mailchimp For Wp > Form.', 'mahic-core' ),
				'section' => 'mahic_maintenance_settings_section',
				'default' => '',
				'active_callback' => [
					[
					  'setting'  => 'mahic_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],
			)
		);
		
		/*====== Maintenance Image ======*/
		mahic_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'mahic_maintenance_image',
				'label' => esc_attr__( 'Background Image', 'mahic-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'mahic-core' ),
				'section' => 'mahic_maintenance_settings_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'input_attrs' => array( 'class' => 'my_custom_class' ),
				'active_callback' => [
					[
					  'setting'  => 'mahic_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],

			)
		);